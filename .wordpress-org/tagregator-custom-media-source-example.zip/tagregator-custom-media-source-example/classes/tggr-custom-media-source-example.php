<?php

if ( $_SERVER['SCRIPT_FILENAME'] == __FILE__ )
	die( 'Access denied.' );

if ( ! class_exists( 'TGGRCustomMediaSourceExample' ) ) {
	/**
	 * Creates a custom post type and associated taxonomies
	 * todo describe what your module does (e.g., "implements Facebook's search API") 
	 */
	class TGGRCustomMediaSourceExample extends TGGRMediaSource {
		protected static $readable_properties  = array( 'view_folder' );
		protected static $writeable_properties = array();
		protected $setting_names, $default_settings, $view_folder;

		// todo customize all of these constants below
		const POST_TYPE_NAME_SINGULAR = 'Custom Media Source Item';
		const POST_TYPE_NAME_PLURAL   = 'Custom Media Source Items';
		const POST_TYPE_SLUG          = 'tggr-cms-items';
		const SETTINGS_TITLE          = 'Custom Media Source';
		const SETTINGS_PREFIX         = 'tggr_cmse_';
		const API_URL                 = 'https://api.example.com';	// It's important to use HTTPS for security


		/**
		 * Constructor
		 * @mvc Controller
		 */
		protected function __construct() {
			$this->view_folder   = dirname( __DIR__ ) . '/views/'. str_replace( '.php', '', basename( __FILE__ ) );
			$this->setting_names = array( 'API Key', '_newest_item_id' );	// todo create your settings here. any setting prefixed with an underscore will be hidden to users, instead of being displayed on the settings screen

			foreach ( $this->setting_names as $key ) {
				$this->default_settings[ strtolower( str_replace( ' ', '_', $key ) ) ] = '';
			}
			$this->default_settings[ '_newest_item_id' ] = 0;
			// todo specify default values for any settings that don't default to an empty string 

			$this->register_hook_callbacks();
		}

		/**
		 * Prepares site to use the plugin during activation
		 * @mvc Controller
		 *
		 * @param bool $network_wide
		 */
		public function activate( $network_wide ) {
			$this->init();
		}

		/**
		 * Rolls back activation procedures when de-activating the plugin
		 * @mvc Controller
		 */
		public function deactivate() {}

		/**
		 * Register callbacks for actions and filters
		 * @mvc Controller
		 */
		public function register_hook_callbacks() {
			add_action( 'init',                                       array( $this, 'init' ) );
			add_action( 'admin_init',                                 array( $this, 'register_settings' ) );

			add_filter( Tagregator::PREFIX . 'default_settings',      __CLASS__ . '::register_default_settings' );
		}

		/**
		 * Initializes variables
		 * @mvc Controller
		 */
		public function init() {
			self::register_post_type( self::POST_TYPE_SLUG, $this->get_post_type_params( self::POST_TYPE_SLUG, self::POST_TYPE_NAME_SINGULAR, self::POST_TYPE_NAME_PLURAL ) );
			self::create_post_author();   // It should already exist from the first time this class was instantiated, but we need to make sure it still exists now
			self::get_post_author_user_id();
		}

		/**
		 * Executes the logic of upgrading from specific older versions of the plugin to the current version
		 * @mvc Model
		 *
		 * @param string $db_version
		 */
		public function upgrade( $db_version = 0 ) {}

		/**
		 * Validates submitted setting values before they get saved to the database. Invalid data will be overwritten with defaults.
		 * @mvc Model
		 *
		 * @param array $new_settings
		 * @return array
		 */
		public function validate_settings( $new_settings ) {
			$new_settings = shortcode_atts( $this->default_settings, $new_settings, TGGRSettings::SETTING_SLUG );

			foreach ( $new_settings as $setting => $value ) {
				switch( $setting ) {
					/*
					 * todo
					 * Add cases for any settings that need custom validation here. the default case below will handle normal text fields. 
					 * Be careful because api keys have characters that are stripped by sanitize_text_field(), so you'll need to setup a custom case for them.
					 */

					default:
						if ( is_string( $value ) ) {
							$new_settings[ $setting ] = sanitize_text_field( $value );
						} else {
							$new_settings[ $setting ] = $this->default_settings[ $setting ];
						}
						break;
				}
			}

			return $new_settings;
		}

		/**
		 * Fetches new items from an external sources and saves them as posts in the local database
		 * @mvc Controller
		 *
		 * @param string $hashtag
		 */
		public function import_new_items( $hashtag ) {
			$items = self::get_new_source_items(
				TGGRSettings::get_instance()->settings[ __CLASS__ ]['api_key'],
				$hashtag,
				TGGRSettings::get_instance()->settings[ __CLASS__ ]['_newest_item_id']
			);

			$this->import_new_posts( $this->convert_items_to_posts( $items, $hashtag ) );
			self::update_newest_item_id( $hashtag );
		}

		/**
		 * Retrieves items containing the given hashtag that were posted since the last import
		 * @mvc Model
		 *
		 * @param string $api_key
		 * @param string $hashtag
		 * @param int $since_id The ID of the most recent item that is already saved in the database
		 * @return mixed string|false
		 */
		protected static function get_new_source_items( $api_key, $hashtag, $since_id ) {
			$items = false;

			if ( $api_key && $hashtag ) {
				$url = sprintf(		// todo update this with the URL for API requests
					'%s/version-number/endpoint/%s?api_key=%s&since_id=%d',
					self::API_URL,
					urlencode( str_replace( '#', '', $hashtag ) ),
					urlencode( $api_key ),
					urlencode( $since_id )
				);

				$response = json_decode( wp_remote_retrieve_body( wp_remote_get( $url ) ) );	// todo don't json_decode() if the response isn't json

				if ( isset( $response->items ) && ! empty( $response->items ) ) {	// todo check the response to see where the items are stored
					$items = $response->items;
				}
			}

			return $items;
		}

		/**
		 * Converts data from external source into a post/postmeta format so it can be saved in the local database
		 * @mvc Model
		 *
		 * @param array $items
		 * @param string $term
		 * @return array
		 */
		public function convert_items_to_posts( $items, $term ) {
			$posts = array();

			/*
			 * todo
			 * Almost everything in this method will need to be customized to match the data returned by the API.
			 * Make sure you properly validate the data for security purposes. See http://codex.wordpress.org/Data_Validation
			 */
			
			if ( $items ) {
				foreach ( $items as $item ) {
					$post_timestamp_gmt   = strtotime( $item->created_at );
					$post_timestamp_local = self::convert_gmt_timestamp_to_local( $post_timestamp_gmt );

					$post = array(
						'post_author'   => TGGRMediaSource::$post_author_id,
						'post_content'  => wp_kses( $item->text, wp_kses_allowed_html( 'data' ), array( 'http', 'https', 'mailto' ) ),
						'post_date'     => date( 'Y-m-d H:i:s', $post_timestamp_local ),
						'post_date_gmt' => date( 'Y-m-d H:i:s', $post_timestamp_gmt ),
						'post_status'   => 'publish',
						'post_title'    => sanitize_text_field( $item->title ),
						'post_type'     => self::POST_TYPE_SLUG,
					);

					$post_meta = array(
						'source_id'        => sanitize_text_field( $item->id ),
						'author_name'      => sanitize_text_field( $item->user->name ),
						'author_username'  => sanitize_text_field( $item->user->screen_name ),
						'author_url'       => isset( $item->user->entities->url->urls[0]->expanded_url ) ? esc_url( $item->user->entities->url->urls[0]->expanded_url ) : '',
						'author_image_url' => esc_url( $item->user->profile_image_url ),
						'media'            => array(),
					);

					if ( isset ( $item->entities->media ) ) {
						foreach ( $item->entities->media as $media_item ) {
							if ( 'photo' == $media_item->type ) {
								$post_meta['media'][] = array(
									'id'   => sanitize_text_field( $media_item->id_str ),
									'url'  => esc_url_raw( $media_item->media_url ),
									'type' => 'image',
								);
							}
						}
					}

					$posts[] = array(
						'post'       => $post,
						'post_meta'  => $post_meta,
						'term_name'  => $term,
					);
				}
			}

			return $posts;
		}

		/**
		 * Updates the _newest_item_id setting with the ID of the most recent
		 * @mvc Model
		 *
		 * @param string $hashtag
		 */
		protected static function update_newest_item_id( $hashtag ) {
			$latest_post = self::get_latest_hashtagged_post( self::POST_TYPE_SLUG, $hashtag );

			if ( isset( $latest_post->ID ) ) {
				$source_id = get_post_meta( $latest_post->ID, 'source_id', true );

				if ( $source_id ) {
					$settings = TGGRSettings::get_instance()->settings;
					$settings[ __CLASS__ ]['_newest_item_id'] = $source_id;
					TGGRSettings::get_instance()->settings = $settings;
				}
			}
		}

		/**
		 * Gathers the data that the media-item view will need
		 * @mvc Model
		 *
		 * @param int $post_id
		 * @return array
		 */
		public function get_item_view_data( $post_id ) {
			// todo update this to match the data needed inside your views/tggr-custom-media-source-example/shortcode-tagregator-media-item.php file
			
			$postmeta = get_post_custom( $post_id );
			$necessary_data = array(
				'item_id'          => $postmeta['source_id'][0],
				'author_name'      => $postmeta['author_name'][0],
				'author_username'  => $postmeta['author_username'][0],
				'author_image_url' => $postmeta['author_image_url'][0],
				'media'            => isset( $postmeta['media'][0] ) ? maybe_unserialize( $postmeta['media'][0] ) : array(),
			);

			return $necessary_data;
		}
	} // end TGGRCustomMediaSourceExample
}
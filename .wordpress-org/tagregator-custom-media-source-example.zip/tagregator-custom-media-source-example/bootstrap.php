<?php
/*
Plugin Name: Tagregator Custom Media Source Example
Plugin URI:  http://plugins.svn.wordpress.org/tagregator/assets/tagregator-custom-media-source-example.zip
Description: Provides an example of how to add a custom media source to Tagregator
Version:     0.1
Author:      WordCamp.org
Author URI:  http://wordcamp.org
*/

/*
 * This is an example of how to build a custom media source for the Tagregator plugin
 * 
 * You should go through the code line-by-line and learn how it works, then customize everything to fit your needs.
 * You should give it a new class name, filenames, slugs, etc.
 * You'll also need to customize any place where you see the "todo" keyword
 * 
 * When in doubt, study the official Twitter/Instagram/Flickr sources to see how they do things.
 * If you run into a problem you can't solve, try asking for help on the Tagregator support forum.
 *  
 * Please consider submitting your custom plugin to the WordPress.org repository, so that others can benefit from it.
 * See http://wordpress.org/plugins/about/ for details on that process.
 */

if ( $_SERVER['SCRIPT_FILENAME'] == __FILE__ )
	die( 'Access denied.' );

function tcmse_register_custom_media_sources( $media_sources ) {
	require_once( dirname( __FILE__ ) . '/classes/tggr-custom-media-source-example.php' );
	$media_sources[ 'TGGRCustomMediaSourceExample' ] = TGGRCustomMediaSourceExample::get_instance();
	
	return $media_sources;
}
add_filter( 'tggr_media_sources', 'tcmse_register_custom_media_sources' );
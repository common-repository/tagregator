<?php 
	/*
	 * The HTML below will be output for each setting, and will work by default for text fields.
	 * If you'd like different markup for different settings, you can check the value of the $setting variable to conditionally output different markup. e.g.,
	 * 
	 * if ( 'foo' == $setting ) :
	 *     // output your new markup
	 * else :
	 *     // output the regular markup  
	 */
?>

<input
	type="text"
	id="<?php echo esc_attr( $class::SETTINGS_PREFIX . $setting ); ?>"
	name="<?php echo esc_attr( Tagregator::PREFIX ); ?>settings[<?php echo esc_attr( $class ); ?>][<?php echo esc_attr( $setting ); ?>] ); ?>"
	class="regular-text"
	value="<?php echo esc_attr( TGGRSettings::get_instance()->settings[ $class ][ $setting ] ); ?>"
/>